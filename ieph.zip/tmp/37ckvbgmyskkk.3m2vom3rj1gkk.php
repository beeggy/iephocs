<div class="page-wrapper" style="min-height: 496px;">
  <div class="content container-fluid">

    <div class="row">
      <div class="col-xs-12">
        <h4 class="page-title">
        <?php if ($seller->id): ?>
          
            Edit Seller
          
          <?php else: ?>
            Add Seller
          
        <?php endif; ?>
        </h4>
      </div>
    </div>
    <div class="row">
      <div class="col-xs-12">
        <div class="card-box">
          <?php if ($message): ?>     
            <div class="alert alert-<?php echo $message['type']; ?> alert-dismissible">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              <?php echo $message['data']; ?>
            </div>
          <?php endif; ?>
          <div class="box box-primary">
            <div class="box-header with-border">
               <h3 class="box-title"> Account Details</h3>
            </div>
            <form role="form" action="<?php echo $URI; ?>" method="POST" class="form-horizontal">
              <div class="box-body">
                <?php if (!$seller->id): ?>
                <div class="form-group">
                  <label class="control-label col-lg-12">First name</label>
                  <div class="col-md-12">
                    <input class="form-control" placeholder="First name" name="firstname" type="text" value="<?php echo $seller->firstname; ?>" required>
                  </div>
                </div>
                <div class="form-group">
                  <label class="control-label col-lg-12">Last name</label>
                  <div class="col-md-12">
                    <input class="form-control" placeholder="Last name" name="lastname" type="text" value="<?php echo $seller->lastname; ?>" required>
                  </div>
                </div>
                <div class="form-group">
                  <label class="control-label col-lg-12">Username</label>
                  <div class="col-md-12">
                    <input class="form-control" placeholder="Username" name="username" type="text" value="<?php echo $seller->username; ?>" required>
                  </div>
                </div>
                <?php endif; ?>
                  <div class="form-group">
                    <label class="control-label col-lg-12">Password</label>
                    <div class="col-md-12">
                      <input class="form-control" placeholder="New Password" name="password" type="password" required>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="control-label col-lg-12">Confirm Password</label>
                    <div class="col-md-12">
                      <input class="form-control" placeholder="Re-enter Password" name="password_confirmation" type="password" required>
                    </div>
                  </div>
                <?php if (!$seller->id): ?>
                <div class="form-group">
                  <label class="control-label col-lg-12">Email</label>
                  <div class="col-md-12">
                    <input class="form-control" placeholder="Email" name="email" type="text" value="<?php echo $seller->email; ?>" required>
                  </div>
                </div>
                <div class="form-group">
                  <label class="control-label col-lg-12">Balance</label>
                  <div class="col-md-12">
                    <div class="input-group">
                          <span class="input-group-addon">₱</span>
                        <input class="form-control" placeholder="100" name="saldo" type="number" step="1" placeholder="<?php echo $seller->saldo; ?>" required>
                    </div>
                  </div>
                </div>
                <?php endif; ?>
                <div align="right">
                  <button type="submit" class="btn btn-primary">Save</button>
                  <?php if ($seller->id): ?>
                    
                      <?php if ($seller->active==1): ?>
                        
                          <a href="<?php echo $URI.'/active/0'; ?>" class="btn btn-warning">Locked</a>
                        
                        <?php else: ?>
                          <a href="<?php echo $URI.'/active/1'; ?>" class="btn btn-success">Unlocked</a>
                        
                      <?php endif; ?>
                      <a href="<?php echo $URI.'/delete'; ?>" class="btn btn-danger hapus">Delete</a>
                    
                    <?php else: ?>
                    
                  <?php endif; ?>
                  <a href="/home/admin/seller" class="btn btn-default">Back</a>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>

  </div>
</div>