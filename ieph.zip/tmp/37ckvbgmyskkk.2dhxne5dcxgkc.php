<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>IEPHSHH-THE BEST SSH/VPN PROVIDER</title>
  
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">

  
      <link rel="stylesheet" href="/css/style.css">

  
</head>

<body>

<div class="form" id="form">
  <div class="field username">
<?php if ($message): ?>
	                    <div class="alert alert-<?php echo $message['type']; ?>"><?php echo $message['data']; ?></div>
	                <?php endif; ?>
                    <form action="/login" method="post">
    <div class="icon"></div>
    <input class="input" type="username" required="required" id="username" name="username" value="" placeholder="Username">
  </div>
  <div class="field password">
    <div class="icon"></div>
    <input class="input" required="required" id="password" type="password" name="password" placeholder="Password">
  </div>
  <button class="button" name="submit" type="submit">LOGIN
    <div class="side-top-bottom"></div>
    <div class="side-left-right"></div>
  </button>
<br><center>Made by PHC-Raf</center>
</div>
  <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js'></script>

  

    <script  src="/js/index.js"></script>




</body>

</html>
