<?php die();
[globals]
DEBUG=0
AUTOLOAD="controller/;model/"
UI="view/"
APP_KEY="6d872a943257faea19b467e7fad0912c0872304bb21dba6cbe1d28cad2c6e296"
DB_SET="mysql:host=localhost;port=3306;dbname=OCS_PANELraf"
DB_USER="root"
DB_PASS="Deb7OCSv2raf"
?>